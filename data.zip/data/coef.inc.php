<?php 
 return array(
     'fabric'    => 5.5,
     'service'   => 5.5,
 );
?>