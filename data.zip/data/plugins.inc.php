<?php

return array (
  'on_run_action' => 
  array (
    'short_store_url' => 
    array (
    ),
  ),
  'after_opening' => 
  array (
    'open_email' => 
    array (
      'subject' => '欢迎加入！',
      'content' => '欢迎加入！生意兴隆～',
    ),
  ),
);

?>