<?php

return array (
  'cleanup' => 
  array (
    'cycle' => 'custom',
    'interval' => 3600,
    'due_time' => 1496650630,
    'last_time' => 1496647030,
  ),
);

?>