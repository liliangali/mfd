<?php

return array (
  '婚庆主题系列' => 
  array (
    'name' => '星耀红毯',
    'img' => 'http://rctailor.ec51.com.cn/upload/images/dis/201406/98f/5f661d15f15e636588956af3f055b8a5.jpg',
    'link' => 'http://www.baidu.com',
  ),
  '校园主题系列' => 
  array (
    'name' => '花样美男',
    'img' => 'http://rctailor.ec51.com.cn/upload/images/dis/201406/98f/c7f75db4ed75080d8f5ed9b6a1b9fe6c.jpg',
    'link' => 'http://www.googel.com',
  ),
  '职场主题系列' => 
  array (
    'name' => '风云领袖',
    'img' => 'http://rctailor.ec51.com.cn/upload/images/dis/201406/98f/3142867959e106b1c2caf8b46fba11fe.jpg',
    'link' => 'http://www.sohu.com',
  ),
  '休闲主题系列' => 
  array (
    'name' => '闲情雅致',
    'img' => 'http://rctailor.ec51.com.cn/upload/images/dis/201406/98f/b0a684341de7d73f07dfb480933ca3ba.jpg',
    'link' => 'http://www.sohu.com',
  ),
  '儿童主题系列' => 
  array (
    'name' => '绅士童年',
    'img' => 'http://rctailor.ec51.com.cn/upload/images/dis/201406/98f/1160ae36048ffab48959534a5ac01f20.jpg',
    'link' => 'http://www.sohu.com',
  ),
);

?>