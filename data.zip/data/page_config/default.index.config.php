<?php

return array (
  'widgets' => 
  array (
    '_widget_590' => 
    array (
      'name' => 'cycle_image',
      'options' => 
      array (
        0 => 
        array (
          'ad_image_url' => 'data/files/mall/template/5fb5733f6b091f4ff58e89516fea1046.jpg',
          'ad_link_url' => '/index.php/custom.html',
        ),
        1 => 
        array (
          'ad_image_url' => 'data/files/mall/template/8aba9f050fda60f2705f1bdc4157b880.jpg',
          'ad_link_url' => '/index.php/custom-lists-7.html',
        ),
        2 => 
        array (
          'ad_image_url' => 'data/files/mall/template/235b4e69c5d36c4584631f85ae2a7d1a.jpg',
          'ad_link_url' => '#',
        ),
      ),
    ),
    '_widget_493' => 
    array (
      'name' => 'dissertation',
      'options' => 
      array (
        0 => 
        array (
          'ad_image_url' => 'data/files/mall/template/26372b6f4803e82f41a927610c0342b7.png',
          'ad_link_url' => 'index.php/custom.html#4',
          'series' => '闲情雅致',
          'adname' => '闲情雅致',
        ),
        1 => 
        array (
          'ad_image_url' => 'data/files/mall/template/83f12a2ac0326b5c3c1b406f28626f77.png',
          'ad_link_url' => 'index.php/custom.html#2',
          'series' => '花样美男',
          'adname' => '花样美男',
        ),
        2 => 
        array (
          'ad_image_url' => 'data/files/mall/template/0723ce1629d9d7e87fd441996335c4f1.png',
          'ad_link_url' => 'index.php/custom.html#1',
          'series' => '星耀红毯',
          'adname' => '星耀红毯',
        ),
        3 => 
        array (
          'ad_image_url' => 'data/files/mall/template/a24368fee342152635038d7f4490ab72.jpg',
          'ad_link_url' => 'index.php/custom.html#3',
          'series' => '风云领袖',
          'adname' => '风云领袖',
        ),
        4 => 
        array (
          'ad_image_url' => 'data/files/mall/template/e260a216096b0703bbd8cb2dccc92573.png',
          'ad_link_url' => 'index.php/custom.html#5',
          'series' => '绅士童年',
          'adname' => '绅士童年',
        ),
      ),
    ),
    '_widget_160' => 
    array (
      'name' => 'advt',
      'options' => 
      array (
        'start_date' => '2014-06-02',
        'end_date' => '2014-10-31',
        'style' => 'image',
        'url1' => '/html/images/sysdtu.jpg',
        'link2' => '#',
        'width1' => '',
        'height1' => '',
        'alt' => '',
      ),
    ),
  ),
  'config' => 
  array (
    'topad' => 
    array (
      0 => '_widget_590',
    ),
    'dissertation' => 
    array (
      0 => '_widget_493',
    ),
    'indexad' => 
    array (
      0 => '_widget_160',
    ),
  ),
);

?>