<?php
return array (
  'version' => '1.0',
  'release' => '20140318',
); 
?>