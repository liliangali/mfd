<?php echo $this->fetch('header.html'); ?>
<link href="templates/jquery-tipso/css/tipso.min.css" type="text/css" rel="stylesheet"/>
<script src="templates/jquery-tipso/js/jquery-1.8.3.min.js"></script>
<script src="templates/jquery-tipso/js/tipso.min.js"></script>
<div id="rightTop">
    <p><b>订单详情</b></p>
    <p><b>&nbsp;&nbsp;<a href="<?php if ($this->_var['reUrl']): ?><?php echo $this->_var['reUrl']; ?><?php else: ?>index.php?app=order&amp;act=export<?php endif; ?>">返回</a></b></p>
</div>
<div class="info">
    <div class="demand">
    </div>
    <div class="order_form">
        <h1>订单日志</h1>
        <ul style="width: 500px;">
            <?php $_from = $this->_var['order_log_list']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }; $this->push_vars('lovk', 'log');if (count($_from)):
    foreach ($_from AS $this->_var['lovk'] => $this->_var['log']):
?>
                <li style="float: left;width: 500px;" data-tipso="<?php echo $this->_var['log']['remark']; ?>"  <?php if ($this->_var['log']['remark']): ?>onmouseover="titleMouseOver(this);"<?php endif; ?> ">(<?php echo local_date("Y/m/d H:i",$this->_var['log']['alttime']); ?>)&nbsp;&nbsp;<span class="red_common"><?php echo $this->_var['log']['log_text']; ?></span>&nbsp;&nbsp;操作人:&nbsp;<span class="red_common"><?php echo $this->_var['log']['op_name']; ?></span></li>
            <?php endforeach; endif; unset($_from); ?><?php $this->pop_vars();; ?>
        </ul>
        <div class="clear"></div>
    </div>
        <div class="order_form">
        <h1>订单状态</h1>
        <ul>
            <li>订单号 ：<?php echo $this->_var['order']['order_sn']; ?></li>
            <li>订单状态 ：
            <?php if ($this->_var['order']['extension'] == 'fabricbook'): ?>
            <?php echo $this->_var['lang']['fabricBookOrderStatus'][$this->_var['order']['status']]; ?>
            <?php else: ?>
            <?php echo $this->_var['lang']['ORDER_STATUS'][$this->_var['order']['status']]; ?>
            <?php endif; ?>
            <?php if ($this->_var['order']['express']): ?> - 快递单号：<?php echo $this->_var['order']['express']; ?><?php endif; ?>
			<?php if ($this->_var['order']['orderrefund_id']): ?> <a href="index.php?app=orderrefund&amp;act=view&amp;id=<?php echo $this->_var['order']['orderrefund_id']; ?>">查看退款详情></a><?php endif; ?>
			</li>



            <?php if ($this->_var['order']['express']): ?> - 快递单号：<?php echo $this->_var['order']['express']; ?>  - 发货时间：<?php echo local_date("Y/m/d H:i",$this->_var['order']['ship_time']); ?>  - 更新帐号：<?php echo $this->_var['order']['deliver_name']; ?> <?php endif; ?></li>
            <li>订单总价 ：<span class="red_common"><?php echo price_format($this->_var['order']['order_amount']); ?></span></li>
            <li>零售总价 ：<span class="red_common"><?php echo price_format($this->_var['order']['goods_amount']); ?></span></li>
           <!--  <li>余额支付 ：<span class="red_common"><?php echo price_format($this->_var['order']['money_amount']); ?></span></li> -->
            <!-- <li>麦富迪币：<span class="red_common"><?php echo price_format($this->_var['order']['coin']); ?></span></li> -->
            <li>优惠券  ：<span class="red_common"><?php echo price_format($this->_var['order']['debit_amount']); ?></span>
            <?php if ($this->_var['dlist']): ?>
             (
              <?php $_from = $this->_var['dlist']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }; $this->push_vars('dKey', 'dItem');if (count($_from)):
    foreach ($_from AS $this->_var['dKey'] => $this->_var['dItem']):
?>
              <?php echo $this->_var['dItem']['d_name']; ?>:<?php echo price_format($this->_var['dItem']['d_money']); ?>
              <?php endforeach; endif; unset($_from); ?><?php $this->pop_vars();; ?>
              )
              <?php endif; ?>
            </li>
           <!--  <li>酷卡  ：<span class="red_common"><?php echo price_format($this->_var['order']['kuka_amount']); ?><br/></span>
            <?php if ($this->_var['kuka']): ?>
              <?php $_from = $this->_var['kuka']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }; $this->push_vars('dKey', 'dItem');if (count($_from)):
    foreach ($_from AS $this->_var['dKey'] => $this->_var['dItem']):
?>
             编号：(<?php echo $this->_var['dItem']['k_sn']; ?>) 金额:<?php echo price_format($this->_var['dItem']['k_money']); ?> (<?php echo $this->_var['dItem']['is_line']; ?>)<br/>
              <?php endforeach; endif; unset($_from); ?><?php $this->pop_vars();; ?>
              <?php endif; ?>
            </li> -->
            <li>[<?php echo $this->_var['order']['payment_name']; ?>]支付 ：<span class="red_common"><?php if ($this->_var['real']): ?><?php echo price_format($this->_var['order']['final_amount']); ?><?php else: ?><?php echo price_format($this->_var['real_amount']); ?><?php endif; ?></span></li>
			<?php if ($this->_var['has_delay']): ?>
			<li>收货延期 ：<span class="red_common">
				用户已申请延期收货，操作时间:<?php echo local_date("Y-m-d H:i:s",$this->_var['has_delay']['delay_time']); ?>
			</span></li>
			<?php endif; ?>

      
        </ul>
        <div class="clear"></div>
    </div>
    <?php if ($this->_var['order']['invoice_need']): ?>
    <div class="order_form">
        <h1>发票信息:</h1>
        <ul>
          <li>发票类型：<?php if ($this->_var['order']['invoice_com'] == '1'): ?>个人<?php else: ?>公司<?php endif; ?></li>
           <li>发票抬头：<?php echo $this->_var['order']['invoice_type']; ?></li>
           <?php if ($this->_var['order']['invoice_com'] == '3'): ?>
           <?php $_from = $this->_var['order']['invoice_title']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }; $this->push_vars('taxKey', 'tax');if (count($_from)):
    foreach ($_from AS $this->_var['taxKey'] => $this->_var['tax']):
?>
           <li><?php echo $this->_var['invoice'][$this->_var['taxKey']]; ?> ：<?php echo $this->_var['tax']; ?></li>
           <?php endforeach; endif; unset($_from); ?><?php $this->pop_vars();; ?>
           <?php else: ?><li>发票内容 ：<?php echo $this->_var['order']['invoice_title']; ?></li><?php endif; ?>
         </ul>
          <div class="clear"></div>
      </div>
    <?php endif; ?>
    <div class="order_form">
        <h1>收货信息:</h1>
        <ul>
        
          <li>收货人：<?php echo $this->_var['order']['ship_name']; ?></li>
           <li>收货人电话：<?php echo $this->_var['order']['ship_mobile']; ?></li>
           <li>收货地址 ：<?php echo $this->_var['order']['ship_area']; ?> <?php echo $this->_var['order']['ship_addr']; ?></li>

            <?php if ($this->_var['order']['extension'] != 'fabricbook'): ?>
            <?php if ($this->_var['order']['status'] == ORDER_ACCEPTED): ?><?php if ($this->_var['has_check'] == 'yes'): ?><li>审核订单 ：<a href="index.php?app=order&act=check&tp=go&id=<?php echo $this->_var['order']['order_id']; ?>"><span>通过</span></a> | <a href="index.php?app=order&act=check&tp=bc&id=<?php echo $this->_var['order']['order_id']; ?>"><span>不通过</span></a> | <a href="index.php?app=order&act=check&tp=no&id=<?php echo $this->_var['order']['order_id']; ?>">取消</a></li><?php endif; ?><?php endif; ?>
            <?php if ($this->_var['order']['status'] == ORDER_SHIPPED): ?><li>订单操作 ：<a href="index.php?app=order&act=check&tp=fini&id=<?php echo $this->_var['order']['order_id']; ?>"><span>完成</span></a> | <a href="index.php?app=order&act=check&tp=no&id=<?php echo $this->_var['order']['order_id']; ?>"><span>作废</span></a> <?php endif; ?>
            <?php if ($this->_var['order']['status'] == ORDER_PRODUCTION || $this->_var['order']['status'] == ORDER_STOCKING || $this->_var['order']['status'] == ORDER_ACCEPTED || $this->_var['order']['status'] == ORDER_SHIPPED): ?>
            <form action="index.php?app=order&act=opts" method="POST">
            <li style="color:red;font-weight:bold;">
                 发货单号：<input type="text" name="waybillno" value="<?php echo $this->_var['order']['waybillno']; ?>" >
                <input type="submit" name="ship"  value="去发货">(该功能为人工发货使用,不懂慎用)
            </li>
            <input type="hidden" name="order_id" value="<?php echo $this->_var['order']['order_id']; ?>">
            </form>
            <?php endif; ?>
            <?php else: ?>
            <form action="index.php?app=order&act=opt" method="POST">
                <?php if ($this->_var['operation']): ?>
                <li style="color:red;font-weight:bold;">客服操作：
                    <?php if ($this->_var['operation']['cancel']): ?>
                    <input type="submit" name="cancel" value="取消订单">
                    <?php endif; ?>
                    <?php if ($this->_var['operation']['returned']): ?>
                    <input type="submit" name="returned" value="已退货">
                    <?php endif; ?>
                    <?php if ($this->_var['operation']['ship']): ?>
                    发货单号：<input type="text" name="express" value="">
                    <input type="submit" name="ship" value="去发货">
                    <?php endif; ?>
                </li>
                <input type="hidden" name="order_id" value="<?php echo $this->_var['order']['order_id']; ?>">
            </form>
            <?php endif; ?>
            <?php endif; ?>
        </ul>
        <div class="clear"></div>
    </div>
    <div class="order_form">
        <h1>订单详情</h1>
        <ul>
            <li>用户名 ：<?php echo htmlspecialchars($this->_var['order']['user_name']); ?></li>
            <?php if ($this->_var['order']['payment_code']): ?>
            <li>支付方式 ：<?php echo htmlspecialchars($this->_var['order']['payment_name']); ?></li>
            <?php endif; ?>
            <?php if ($this->_var['order']['pay_message']): ?>
            <li>支付留言  ：<?php echo htmlspecialchars($this->_var['order']['pay_message']); ?></li>
            <?php endif; ?>
            <li>下单时间 ：<?php echo local_date("Y-m-d H:i:s",$this->_var['order']['add_time']); ?></li>
            <?php if ($this->_var['order']['pay_time']): ?>
            <li>支付时间 ：<?php echo local_date("Y-m-d H:i:s",$this->_var['order']['pay_time']); ?></li>
            <?php endif; ?>
            <?php if ($this->_var['order']['shipping_id']): ?>
            <li>配送方式 ：<?php echo $this->_var['order']['shipping']; ?></li>
            <?php endif; ?>
            <?php if ($this->_var['order']['one_num']): ?>
            <li>员工号：<?php echo $this->_var['order']['one_num']; ?></li>
            <?php endif; ?>
            <li>类型：
            <?php if ($this->_var['order']['is_gift'] == 1): ?>
            礼品
            <?php else: ?>
            普通
            <?php endif; ?>
            </li>
            <?php if ($this->_var['order']['memo']): ?>
            <li>订单备注 ：<?php echo $this->_var['order']['memo']; ?></li>
            <?php endif; ?>
        </ul>
        <div class="clear"></div>
    </div>
  <div class="order_form">
        <h1>商品信息</h1>
<?php $_from = $this->_var['order_info']['order_goods']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }; $this->push_vars('', 'list');if (count($_from)):
    foreach ($_from AS $this->_var['list']):
?>
   <!-- <li><?php echo $this->_var['lang'][$this->_var['emb']['e_tname']]; ?> ：<?php echo $this->_var['emb']['e_name']; ?></li> -->
		<img src="<?php echo $this->_var['list']['goods_image']; ?>" width="60" />
		<ul>
		<li>名称 ： <?php echo $this->_var['list']['goods_name']; ?></li>
        <li>类型： <?php if ($this->_var['list']['type'] == 'fdiy'): ?>diy商品<?php else: ?>普通<?php endif; ?></li>
            <li>物流编码 ： <?php echo $this->_var['list']['code']; ?></li>
		<li>属性 ： <?php if ($this->_var['list']['type'] == 'fdiy'): ?><?php echo $this->_var['list']['spe_name']; ?><?php else: ?>
            <?php $_from = $this->_var['list']['spe_name']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }; $this->push_vars('', 'item');if (count($_from)):
    foreach ($_from AS $this->_var['item']):
?>
            <?php echo $this->_var['item']['p_name']; ?>:<?php echo $this->_var['item']['s_name']; ?>&nbsp;
            <?php endforeach; endif; unset($_from); ?><?php $this->pop_vars();; ?>
            <?php endif; ?></li>
        <li>单价 ： <?php echo $this->_var['list']['price']; ?></li>
		<li>数量 ： <?php echo $this->_var['list']['quantity']; ?></li>
		<li>小计 ： <?php echo $this->_var['list']['subtotal']; ?></li>
            <?php if ($this->_var['list']['type'] == 'fdiy'): ?>
            <li>宠物名称 ： <?php echo $this->_var['list']['dog_name']; ?></li>
            <li>宠物生日 ： <?php echo $this->_var['list']['dog_date']; ?></li>
            <li>主人寄语 ： <?php echo $this->_var['list']['dog_desc']; ?></li>
            <li>时间 ： <?php echo $this->_var['list']['time_name']; ?></li>
            <li>运动量 ： <?php echo $this->_var['list']['run_name']; ?></li>
            <li>体况 ： <?php echo $this->_var['list']['body_name']; ?></li>
            <li>体重 ： <?php echo $this->_var['list']['weight']; ?></li>
            <?php if ($this->_var['list']['feed_list']): ?>
            <li>饲喂量 ： <?php echo $this->_var['list']['feed_list']['feed_w']; ?>g/天</li>
            <li>次数 ： <?php echo $this->_var['list']['feed_list']['nums']; ?></li>
            <?php endif; ?>
            <?php endif; ?>
		</ul>
        <div class="clear"></div>
         <hr>
<?php endforeach; endif; unset($_from); ?><?php $this->pop_vars();; ?>
    </div>
</div>

<?php echo $this->fetch('footer.html'); ?>
<script>
    /**
     * 鼠标悬停显示TITLE
     * @params     obj        当前悬停的标签
     *
     */
    function titleMouseOver(obj) {
        $(obj).tipso({
            useTitle: false,
            width:500,
            background:'#55b555'
        });
    }
</script>
