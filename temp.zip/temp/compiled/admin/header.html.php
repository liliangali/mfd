<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<!-- Use IE7 mode -->
<meta http-equiv="X-UA-Compatible" content="IE=EmulateIE7 charset=<?php echo $this->_var['charset']; ?>" />
<meta http-equiv="Content-Type" content="text/html; charset=<?php echo $this->_var['charset']; ?>" />
<title> MyFoodie管理中心 - MyFoodie.com </title>
<link href="templates/style/admin.css" rel="stylesheet" type="text/css" />
<script type="text/javascript">
//<!CDATA[
var SITE_URL = "<?php echo $this->_var['site_url']; ?>";
var REAL_SITE_URL = "<?php echo $this->_var['real_site_url']; ?>";
var REAL_BACKEND_URL = "<?php echo $this->_var['real_backend_url']; ?>";
//]]>
</script>
<script type="text/javascript" src="../../../static/expand/my97date/wdatepicker.js" charset="utf-8"></script>
<script type="text/javascript" src="<?php echo $this->lib_base . "/" . 'jquery.js'; ?>" charset="utf-8"></script>
<script type="text/javascript" src="<?php echo $this->lib_base . "/" . 'jquery.plugins/jquery.validate.js'; ?>" charset="utf-8"></script>
<script type="text/javascript" src="<?php echo $this->lib_base . "/" . 'rctailor.js'; ?>" charset="utf-8"></script>
<script type="text/javascript" src="<?php echo $this->res_base . "/" . 'js/admin.js'; ?>" charset="utf-8"></script>
<script type="text/javascript" src="<?php echo $this->res_base . "/" . 'js/jquery.cookie.js'; ?>" charset="utf-8"></script>
<!--ns up 更改调用地址-->
<script type="text/javascript" src="../../public/global/luck/pc/luck.js" charset="utf-8"></script>
<script type="text/javascript" src="index.php?act=jslang"></script>
<style type="text/css">
<!--
body {background: #fff}
-->
</style>
<?php echo $this->_var['_head_tags']; ?>
</head>
<body>
