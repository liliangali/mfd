<?php echo $this->fetch('header-new.html'); ?>
<link href="/public/static/pc/css/gwc.css" rel="stylesheet">
    <!--空购物袋/S-->
     <div class="kgwc_box">
       <p class="p1"><img src="/public/static/pc/images/kgwc.png"></p>
       <p class="p2">购物车空空的哦，去看看心仪的商品吧~</p>
       <p class="p3"><a href="/">马上去购物</a></p>
     </div>
    <!--空购物袋/E-->
    <script src="/public/global/jquery-1.8.3.min.js"></script> 
<script src="/public/static/pc/js/public.js"></script>
<?php echo $this->fetch('footer-new.html'); ?>

