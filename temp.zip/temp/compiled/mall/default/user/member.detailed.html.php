<?php echo $this->fetch('../header-new.html'); ?>
<style>
.borline td {padding:10px 0px;}
.ware_list th {text-align:left;}
</style>
<link href="/public/static/pc/css/user.css" rel="stylesheet">
<script src="../static/v1/js/jquery.min.js"></script>
<script type="text/javascript" src="static/expand/jquery.js" charset="utf-8"></script>
<script type="text/javascript" src="static/expand/my97date/wdatepicker.js" charset="utf-8"></script> 
<?php echo $this->_var['_head_tags']; ?> 
<script type="text/javascript">
//<!CDATA[
var PINER = {uid: "<?php echo $this->_var['session_info_user_id']; ?>"}; 
var SITE_URL = "<?php echo $this->_var['site_url']; ?>";
var REAL_SITE_URL = "<?php echo $this->_var['real_site_url']; ?>";
var REAL_BACKEND_URL = "<?php echo $this->_var['real_backend_url']; ?>";
var REGION_URL="<?php echo $this->build_url(array('app'=>'mlselection','act'=>'index','arg'=>'region')); ?>";
var reginUrl=REAL_SITE_URL+REGION_URL;
 $(function(){    
    regionInit("region");
}); 
</script>

<div class="user_box">
<?php echo $this->fetch('member.menu.html'); ?>


<div class="user_right fr">

        <div class="lntegral">
            <p class="mlntegral mlntegrals fl">个人资料</p>
        </div>

    <div class="profile">
        <div class="yhname">
            <div class="namexx">
                <p class="portrait personal fl" id="headEdit"><img src="<?php echo $this->_var['avatar']; ?>" width="94" height="94"><img src="/public/static/pc/images/bjpic.png" width="45" height="45" class="edit"></p>
                <div class="member fl">
                    <p class="display"><?php echo $this->_var['user']['nickname']; ?></p>
                    <div class="zhaqc">
                        <p class="hpjw fl">账户安全：</p>
                        <div class="hptia fl"><p style="width:<?php echo $this->_var['percent']; ?>%;background-color:<?php echo $this->_var['color']; ?>"></p></div>&nbsp;&nbsp;<?php if ($this->_var['percent'] < 100): ?> <a href="<?php echo $this->build_url(array('app'=>'member','act'=>'safe')); ?>">完善设置&nbsp;></a><?php endif; ?>
                        <p class="jiaog fl"><?php echo $this->_var['safe_level']; ?></p>
                    </div>
                </div>
                <!--<p class="grzlewm fr"><img src="<?php echo $this->_var['profile']['erweima_url']; ?>"  id="erweima"><br>二维码名片</p>-->
            </div>
            <div class="details">
                <ul>
                    <li>麦券：<span><a style="color:#ff4400" href="<?php echo $this->build_url(array('app'=>'member','act'=>'debit')); ?>"><?php echo $this->_var['profile']['debit_num']; ?></a>张</span></li>
                    <!--<li>积分：<span><?php echo $this->_var['user']['point']; ?>分</span></li>-->
                </ul>
            </div>
        </div>

            <!--详细资料-->
            <div class="grzlqh" >
                <div class="grzltit" id="point">
                	<ul>
                    	<li><a href="member-profile.html#point">基本资料</a></li>
                        <li><span></span></li>
                        <li><a href="#point" class="grzlcur">详细资料</a></li>
                    </ul>
                </div>
                <form method="post" action="member-detailed.html" id="member-detailed">
                <table width="960" border="0" class="grtab">
                    <tr>
                        <td><p class="said fl">QQ：</p><input type="text" class="grzlinp" validate="number" tip="QQ号码" name="im_qq" value="<?php echo $this->_var['profile']['im_qq']; ?>"></td>
                    </tr>
                    <tr>
                        <td><p class="said fl">微信：</p><input type="text" class="grzlinp" validate="weixin" tip="微信" name="wechat" value="<?php echo $this->_var['profile']['wechat']; ?>"></td>
                    </tr>
                    <tr>
                        <td><p class="said fl">邀请人：</p><input type="text" class="grzlinp" name="inviter" <?php if ($this->_var['inviter']['nickname']): ?> disabled <?php endif; ?> value="<?php echo $this->_var['inviter']['nickname']; ?>"></td>
                    </tr>
                    <tr>
                        <td><p class="said fl">生日：</p><input type="text" class="grzlinp" onFocus="WdatePicker({dateFmt:'yyyy-MM-dd',maxDate:'%y-%M-%d'})" name="birthday" value="<?php echo $this->_var['profile']['birthday']; ?>"></td>
                    </tr>
                    <tr>
                        <td><p class="said fl">邀请人：</p><input type="text" class="grzlinp" name="inviter" <?php if ($this->_var['inviter']['nickname']): ?> disabled <?php endif; ?> value="<?php echo $this->_var['inviter']['nickname']; ?>"></td>
                    </tr>
                    <tr>
                        <td><p class="said fl">地址：</p>
                            <select name="country">
                                <option value="1">中国</option>
                            </select>
                            <select  name="p_region_id" onchange="get_region(this)">
                                <?php echo $this->html_options(array('options'=>$this->_var['region1'],'selected'=>$this->_var['p_region_id'])); ?>
                            </select>

                            <select  name="region_id" id="region_id">
                                <?php echo $this->html_options(array('options'=>$this->_var['region2'],'selected'=>$this->_var['profile']['region_id'])); ?>
                            </select>
                        </td>
                    </tr>
                    <tr>
                        <td><input type="submit" value="保存" class="grbut grbuts"></td>
                    </tr>
                </table>
                </form>
            </div>
        </div>
    </div>
</div>
    <?php echo $this->fetch('footer.html'); ?>
    <script src="/public/global/jquery-1.8.3.min.js"></script>
    <script src="/public/global/luck/pc/luck.js"></script>
    <script src="/public/global/jquery.form.js"></script>
    <script src="/public/global/jcrop/js/jquery.Jcrop.js"></script>
    <script src="/public/static/pc/js/public.js"></script>
    <script src="/public/static/pc/js/usercenter.js"></script>
    <link rel="stylesheet" href="/public/global/jcrop/css/jquery.Jcrop.css" type="text/css" />


<script type="text/javascript">
    function get_region(obj)
    {
        var p_id = $(obj).val();
        $.post("./member-get_region.html",{pid:p_id}, function(res){
            var res = eval("("+res+")");
            $('#region_id').empty();
            $('#region_id').append(res.retval)
        });
    }

    //    头像上传
    $('#headEdit').click(function(){
        luck.open({
            title:'修改头像',
            content:'<div class="head-edit"><div class="step1"><form id="uploadForm"><div class="btn">上传头像<input type="file" name="avatar" accept="image/jpeg, image/png" onChange="uploadHead(this)"></div><p>jpg 或 png，大小不超过2M</p></form></div><div class="step2" style="display:none"><div class="picBox" id="picBox"></div><p class="btnBox"><button class="ok">确定</button><button class="reset">重新上传</button></p></div><div class="loading" style="display:none"><img src="/public/static/pc/images/loading.gif" width="90" height="90"><p class="tip">上传中...</p></div></div>',
            width:'400px',
            height:'auto',
            class:'mfd-luck'
        })
    });
    function uploadHead(e){
        $('#uploadForm').ajaxSubmit({
            url:'/member-getImg.html',
            type:'post',
            dataType:'json',
            beforeSubmit:function(a,b,c){
                $('.head-edit .step1').hide();
                $('.head-edit .loading').show();
            },
            success:function(d){
                if(!d.done){
                    alert(d.msg);
                    return
                }
                var data=null;
                var img=new Image;
                img.src=d.retval+'?'+Math.random();
                img.className="img";
                img.onload=function(){
                    //切换状态
                    $('.head-edit .loading').hide();
                    $('.head-edit .step2').show();
                    //追加图片
                    var oDiv=$('<div/>');
                    oDiv.html(this);
                    $('#picBox').html(oDiv);
                    oDiv.css('margin-top',(300-oDiv.height())/2>0?(300-oDiv.height())/2:0);
                    //调用裁剪工具
                    $(this).Jcrop({
                        //完成回调
                        onSelect:function(c){
                            data=c;
                        },
                        //移动回调
                        onChange:function(c){
                            data=c
                        },
                        //背景颜色
                        bgColor:'fff',
                        //背景透明度
                        bgOpacity:'.5',
                        //坐标
                        setSelect: [ 0, 0, 100, 100],//x,y,w,h
                        //最小
                        minSize:[100,100],
                        //最大
                        maxSize:[200,200],
                        //比例
                        aspectRatio:1/1
                    });
                    //绑定按钮事件
                    $('.head-edit .ok').unbind('click').click(function(){
                        $.ajax({
                            url:'/member-editAvatar.html',
                            type:'POST',
                            dataType:"json",
                            data:{
                                data:'{"x":'+data.x+',"y":'+data.y+',"w":'+data.w+',"h":'+data.h+',"imgw":300,"imgh":'+(300/img.width*img.height)+'}',
                                avatar:d.retval
                            },
                            beforeSend: function(){
                                $('.head-edit .step2').hide();
                                $('.head-edit .loading').show();
                            },
                            success: function(d){
                                if(d.done){
                                    $('#headEdit img:eq(0)').attr('src',d.retval.avatar+'?'+Math.random());
                                    $('#erweima').attr('src',d.retval.erweima_url+'?'+Math.random());
                                }else{
                                    alert(d.msg)
                                }
                                luck.close();
                            },
                            error:function(){
                                alert('errorasdfasdf')
                            }
                        })
                    });
                    $('.head-edit .reset').unbind('click').click(function(){
                        $('.head-edit .step1').show();
                        $('.head-edit .step2').hide();
                    });
                }
            },
            error:function(){
                alert('error')
            }
        })
    }
</script>



