<div class="address" id="address">
  <ul>
    <?php $_from = $this->_var['addresslist']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }; $this->push_vars('', 'list');$this->_foreach['ads'] = array('total' => count($_from), 'iteration' => 0);
if ($this->_foreach['ads']['total'] > 0):
    foreach ($_from AS $this->_var['list']):
        $this->_foreach['ads']['iteration']++;
?>
      <li <?php if ($this->_var['list']['addr_id'] == $this->_var['def_addr']): ?>class="cur"<?php endif; ?> data-id="<?php echo $this->_var['list']['addr_id']; ?>">
      <p class="underlined"><?php echo $this->_var['list']['consignee']; ?></p>
      <p class="tele"><?php echo $this->_var['list']['phone_mob']; ?></p>
      <p class="txaddress"><?php echo $this->_var['list']['region_name']; ?><?php echo $this->_var['list']['address']; ?><?php if ($this->_var['list']['zipcode']): ?>(<?php echo $this->_var['list']['zipcode']; ?>)<?php endif; ?>
      <div class="caozuoBtn">
      <input type="button" value="编辑" class="edit" />
      <input type="button" value="删除" class="del" />
      <?php if ($this->_var['list']['addr_id'] == $this->_var['def_addr']): ?>
      <span class="pnmr">默认</span>
      <?php else: ?>
      <input type="button" value="设置默认" class="def" style="width:80px;" />
      <?php endif; ?>
      </div>
      </li>
    <?php endforeach; endif; unset($_from); ?><?php $this->pop_vars();; ?> 
    <li class="syxdz" id="addAddress">
    <span>+</span>
    使用新地址
    </li>
  </ul>
</div>

