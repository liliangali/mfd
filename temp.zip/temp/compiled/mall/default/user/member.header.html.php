<!doctype html>
<html lang="zh-CN">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<?php echo $this->_var['page_seo']; ?>
<link href="/public/static/pc/css/public.css" rel="stylesheet">
<?php echo $this->_var['_head_tags']; ?>
<link rel="shortcut icon" href="favicon.ico" />
<link rel="icon" href="animated_favicon.gif" type="image/gif" />
<style>
.w {max-width:1000px; padding: 10px 0;}
.login_head {background: #fff none repeat scroll 0 0; border-bottom: 1px solid #ededed; height: 82px;}
.dlzc {margin-top:20px;}
.dlzc a {color:#999;}
.dlzc span {color:#999; padding:0 10px;}
</style>
</head>
<body>
<div class="login_head">
   <div class="w"> 
     <div class="fl"><a href="/"><img src="/public/static/pc/images/logo.png" width="248" height="58"></a></div>
     <div class="fr dlzc"><a href="/member-login.html" class="grey">登录</a><span>|</span><a href="/member-register.html" class="grey">注册</a></div>
   </div>
</div>