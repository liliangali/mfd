<!-- <div class="mmszcg">
    <p class="p1">密码设置成功！</p>
    <p class="p2">请牢记你的新密码哦，你可以马上<a href="/member-login.html">登录账号</a></p>
    <p class="p4"><a class="a1" href="/">访问首页</a><a class="a2" href="/member.html">我的麦富迪</a></p>
</div> -->


<!-- 异步加载开始 -->

  <div class="pwd-step pwd-3"><p>1、验证身份</p><p>2、重置登录密码</p><p class="on">3、完成</p></div>
  <div class="verifyOk">
    <div class="txt txt2"><i class="ico fl"></i><span class="fl">新密码设置成功</span>
      <p>请您牢记新密码</p>
    </div>
    <div class="btn2"> <a href="/" class="btn-red fl"><span>返回首页</span></a> </div>
  </div>

<!-- 异步加载结束 -->