  <div class="reg-step reg-3"><p>1、填写账号信息</p><p>2、验证手机/邮箱</p><p class="on">3、注册成功</p></div>
  <div class="verifyOk">
    <div class="txt"><i class="ico fl"></i><span class="fl">恭喜您，<?php echo $this->_var['data']['phone']; ?> 注册成功！</span>
      <p>你的昵称 <font class="cRed"><?php echo $this->_var['name']; ?></font> 会展示在订单管理，商品评价等地方，<br>
        如不希望暴露，建议您：<a href="member-profile.html" class="cRed">修改昵称</a></p>
    </div>
</div>