<div class="diy_step clearfix">
    <ul>
        <li class="<?php if ($this->_var['ps'] != 2): ?>on<?php else: ?>off<?php endif; ?>"><a href="fdiy.html"><i class="step1"></i></a><a href="fdiy.html">选择爱宠品种</a></li>
        <li class="<?php if ($this->_var['ps'] == 2): ?>on<?php else: ?>off<?php endif; ?>"><i class="step2"></i><a href="###">自主搭配食品</a></li>
        <li><i class="step3"></i>加入购物车</li>
        <li class="none"><i class="step4"></i>结算、完成</li>
    </ul>
</div>