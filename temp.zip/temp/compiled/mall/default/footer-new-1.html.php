<script type="text/javascript">
    //baidu
    var _hmt = _hmt || [];
    (function() {
        var hm = document.createElement("script");
        hm.src = "//hm.baidu.com/hm.js?96c2b8c44ecbfb71d690719e24a1eba2";
        var s = document.getElementsByTagName("script")[0];
        s.parentNode.insertBefore(hm, s);
    })();

</script>
<div class="dlzc_db">
    <p class="wdba" style="line-height:130px;"><span>Copyright &copy; 2015 www.mfd.cn</span> <span>All Rights Reserved</span> <span>&nbsp;&nbsp;&nbsp;鲁ICP备14033488号-1</span></p>
</div>
