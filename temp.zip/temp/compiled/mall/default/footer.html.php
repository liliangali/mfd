
<!--底部开始-->
<div class="minfooter">
    <div> <a href="#">关于麦富迪</a><span>|</span> <a href="#">加入我们</a><span>|</span> <a href="#">联系我们</a><span>|</span> <a href="#">常见问题</a><span>|</span> <a href="#">新手入门</a><span>|</span> <a href="#">法律声明</a> </div>
    <p class="copyright">@2015 mfd.cn<span>All rights reserved</span><span>备案号：鲁ICP备14033488号-1</span><span>经营许可证编号：鲁B5-20150328</span></p>
</div>
<!--底部结束--> 


</body>
</html>