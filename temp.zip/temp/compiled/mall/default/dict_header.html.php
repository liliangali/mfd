<!--背景图标-->
<div class="diy_icon1"></div>
<div class="diy_icon2"></div>
<div class="diy_icon3"></div>
<div class="menu_position clearfix">

    <div class="menu">
        <dl>
            <dt><a href="./" target="_blank">首页</a></dt>
            <dt><a href="./gallery.html" target="_blank">麦富迪尚品</a></dt>
            <dd><a href="./gallery.html?p_id=128516" target="_blank">主食</a></dd>
            <dd><a href="./gallery.html?p_id=128519" target="_blank">零食</a></dd>
            <dd><a href="./gallery.html?p_id=128522" target="_blank">湿粮</a></dd>
            <dd><a href="./gallery.html?p_id=128516" target="_blank">咬胶</a></dd>

            <dt><a href="./fdiy-1.html">我要定制</a></dt>
            <dt><a href="./professor-online.html" target="_blank">专家在线</a></dt>
            <dt><a href="./article.html" target="_blank">麦富迪讲堂</a></dt>
            <dt><a href="./down.html" target="_blank">APP下载</a></dt>
        </dl>
    </div>

    <div class="menu_box">
        <p class="logo"><a href="./" target="_blank"><img src="/diy/images/logo2.png"></a></p>
        <p class="menu_img"><i class="icon"></i></p>
        <p class="menu_img2"><i class="icon"></i></p>
    </div>

</div>
