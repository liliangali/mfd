<!--底部开始-->
<div class="minfooter">
 <div>
  <a href="/help-index-about.html">关于麦富迪</a><span>|</span>
  <!-- <a href="/help-index-join_us.html">加入我们</a><span>|</span> -->
  <a href="/help-index-contact_us.html">联系我们</a><span>|</span>
  <a href="/help-index.html">帮助中心</a><span>|</span>
  <a href="/help-index-new_entry.html">新手入门</a><span>|</span>
  <a href="/help-index-disclaimer.html">法律声明</a>
 </div>
 <p class="copyright">@2016 Myfoodie.cn<span>All rights reserved</span><span>备案号：鲁ICP备14033488号-1</span><span><a target="_blank" href="http://www.beian.gov.cn/portal/registerSystemInfo?recordcode=37028202000119" style="color: #888;;">鲁公网安备 37028202000119号</a></span></p>
</div>
<!--底部结束-->
<div style="display:none;">
<script type="text/javascript">
    //baidu
    var _hmt = _hmt || [];
    (function() {
        var hm = document.createElement("script");
        hm.src = "//hm.baidu.com/hm.js?96c2b8c44ecbfb71d690719e24a1eba2";
        var s = document.getElementsByTagName("script")[0];
        s.parentNode.insertBefore(hm, s);
    })();

    var cnzz_protocol = (("https:" == document.location.protocol) ? " https://" : " http://");
    document.write(unescape("%3Cspan id='cnzz_stat_icon_1256310283'%3E%3C/span%3E%3Cscript src='" + cnzz_protocol + "s95.cnzz.com/z_stat.php%3Fid%3D1256310283' type='text/javascript'%3E%3C/script%3E"));
</script>
</div>

