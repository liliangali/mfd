<?php
/**
 *  @Created By RCTailor PhpCacheServer
 *  @Time:2016-12-10 13:12:56
 */

if(filemtime(__FILE__) + 3600 < time())return false;

return array (
  0 => 
  array (
    'id' => '128516',
    'value' => '主食',
    'children' => 
    array (
      0 => 
      array (
        'id' => '128517',
        'value' => '鲜肉无谷粮',
        'children' => 
        array (
        ),
        'top_store' => 0,
      ),
      1 => 
      array (
        'id' => '128518',
        'value' => '优能营养配方粮',
        'children' => 
        array (
        ),
        'top_store' => 0,
      ),
      2 => 
      array (
        'id' => '128525',
        'value' => '功能营养',
        'children' => 
        array (
        ),
        'top_store' => 0,
      ),
      3 => 
      array (
        'id' => '128527',
        'value' => '双色犬粮',
        'children' => 
        array (
        ),
        'top_store' => 0,
      ),
      4 => 
      array (
        'id' => '128528',
        'value' => '鲜肉软犬粮系列',
        'children' => 
        array (
        ),
        'top_store' => 0,
      ),
      5 => 
      array (
        'id' => '128529',
        'value' => '通用犬粮系列',
        'children' => 
        array (
        ),
        'top_store' => 0,
      ),
      6 => 
      array (
        'id' => '128530',
        'value' => '天然猫粮系列',
        'children' => 
        array (
        ),
        'top_store' => 0,
      ),
      7 => 
      array (
        'id' => '128545',
        'value' => '天然犬粮系列',
        'children' => 
        array (
        ),
        'top_store' => 0,
      ),
      8 => 
      array (
        'id' => '128546',
        'value' => '乖宝乐犬粮系列',
        'children' => 
        array (
        ),
        'top_store' => 0,
      ),
      9 => 
      array (
        'id' => '128547',
        'value' => '双料双拼粮',
        'children' => 
        array (
        ),
        'top_store' => 0,
      ),
    ),
    'top_store' => 0,
  ),
  1 => 
  array (
    'id' => '128519',
    'value' => '零食',
    'children' => 
    array (
      0 => 
      array (
        'id' => '128520',
        'value' => '奢华营养',
        'children' => 
        array (
        ),
        'top_store' => 0,
      ),
      1 => 
      array (
        'id' => '128521',
        'value' => '日常营养',
        'children' => 
        array (
        ),
        'top_store' => 0,
      ),
      2 => 
      array (
        'id' => '128550',
        'value' => '乖宝乐系列',
        'children' => 
        array (
        ),
        'top_store' => 0,
      ),
      3 => 
      array (
        'id' => '128551',
        'value' => '奢华营养塑料罐装',
        'children' => 
        array (
        ),
        'top_store' => 0,
      ),
      4 => 
      array (
        'id' => '128552',
        'value' => '独立小包装',
        'children' => 
        array (
        ),
        'top_store' => 0,
      ),
      5 => 
      array (
        'id' => '128553',
        'value' => '烧烤鸡胸肉',
        'children' => 
        array (
        ),
        'top_store' => 0,
      ),
      6 => 
      array (
        'id' => '128555',
        'value' => '牛系列',
        'children' => 
        array (
        ),
        'top_store' => 0,
      ),
      7 => 
      array (
        'id' => '128556',
        'value' => '奢华营养系列',
        'children' => 
        array (
        ),
        'top_store' => 0,
      ),
    ),
    'top_store' => 0,
  ),
  2 => 
  array (
    'id' => '128522',
    'value' => '湿粮',
    'children' => 
    array (
      0 => 
      array (
        'id' => '128523',
        'value' => '日常营养',
        'children' => 
        array (
        ),
        'top_store' => 0,
      ),
      1 => 
      array (
        'id' => '128524',
        'value' => '奢华营养',
        'children' => 
        array (
        ),
        'top_store' => 0,
      ),
      2 => 
      array (
        'id' => '128533',
        'value' => '功能营养',
        'children' => 
        array (
        ),
        'top_store' => 0,
      ),
      3 => 
      array (
        'id' => '128562',
        'value' => '超高端系列',
        'children' => 
        array (
        ),
        'top_store' => 0,
      ),
      4 => 
      array (
        'id' => '128563',
        'value' => '铝盒罐头',
        'children' => 
        array (
        ),
        'top_store' => 0,
      ),
      5 => 
      array (
        'id' => '128564',
        'value' => '泰国原装进口猫罐头',
        'children' => 
        array (
        ),
        'top_store' => 0,
      ),
      6 => 
      array (
        'id' => '128565',
        'value' => '日常罐头',
        'children' => 
        array (
        ),
        'top_store' => 0,
      ),
      7 => 
      array (
        'id' => '128566',
        'value' => '角切罐头',
        'children' => 
        array (
        ),
        'top_store' => 0,
      ),
    ),
    'top_store' => 0,
  ),
  3 => 
  array (
    'id' => '128526',
    'value' => '咬胶',
    'children' => 
    array (
      0 => 
      array (
        'id' => '128534',
        'value' => '纽脆骨系列',
        'children' => 
        array (
        ),
        'top_store' => 0,
      ),
      1 => 
      array (
        'id' => '128535',
        'value' => '清口香系列',
        'children' => 
        array (
        ),
        'top_store' => 0,
      ),
      2 => 
      array (
        'id' => '128536',
        'value' => '牙刷系列',
        'children' => 
        array (
        ),
        'top_store' => 0,
      ),
      3 => 
      array (
        'id' => '128537',
        'value' => '骨头系列',
        'children' => 
        array (
        ),
        'top_store' => 0,
      ),
      4 => 
      array (
        'id' => '128557',
        'value' => '本色系列',
        'children' => 
        array (
        ),
        'top_store' => 0,
      ),
      5 => 
      array (
        'id' => '128558',
        'value' => '磨牙棒系列',
        'children' => 
        array (
        ),
        'top_store' => 0,
      ),
      6 => 
      array (
        'id' => '128559',
        'value' => '洁齿骨系列',
        'children' => 
        array (
        ),
        'top_store' => 0,
      ),
      7 => 
      array (
        'id' => '128560',
        'value' => '真清新系列',
        'children' => 
        array (
        ),
        'top_store' => 0,
      ),
      8 => 
      array (
        'id' => '128561',
        'value' => '清齿倍健系列',
        'children' => 
        array (
        ),
        'top_store' => 0,
      ),
    ),
    'top_store' => 0,
  ),
);

?>