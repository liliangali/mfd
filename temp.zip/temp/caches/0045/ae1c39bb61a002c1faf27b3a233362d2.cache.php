<?php
/**
 *  @Created By RCTailor PhpCacheServer
 *  @Time:2016-12-10 13:09:45
 */

if(filemtime(__FILE__) + 86400 < time())return false;

return 0;

?>